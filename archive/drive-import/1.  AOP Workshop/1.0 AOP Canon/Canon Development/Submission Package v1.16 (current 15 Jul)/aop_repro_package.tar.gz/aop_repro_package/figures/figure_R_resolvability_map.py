import os as _os
_HERE=_os.path.dirname(_os.path.abspath(__file__))
# skill:figure-style kernel.py (auto-injected on skill load)
META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


def panel_letter(ax, letter, dx=-0.18, dy=1.02, case="lower", fontsize=None):
    import matplotlib.pyplot as plt
    if fontsize is None:
        fontsize = plt.rcParams.get("font.size", 8) + 1
    s = letter.lower() if case == "lower" else letter.upper()
    ax.text(dx, dy, s, transform=ax.transAxes,
            fontweight="bold", fontsize=fontsize, va="bottom", ha="left")


import importlib.util
spec = importlib.util.spec_from_file_location("eng", _os.path.join(_HERE,"..","engine","aop_resolvability_engine.py"))
eng = importlib.util.module_from_spec(spec)
spec.loader.exec_module(eng)

import pickle
rows = pickle.load(open(_os.path.join(_HERE,"..","data","persister_rows.pkl"), "rb"))

import matplotlib as mpl, matplotlib.pyplot as plt
apply_figure_style()
fig, ax = plt.subplots(figsize=(8.2, 5.6))
for name, vif, drag, ss, computed, blurb in rows:
    col = "#c0392b" if name=="star" else ("#2c6fbb" if computed else "#95a5a6")
    mk = "o" if computed else "D"
    ax.scatter(vif, drag, s=120 if name=="star" else 80, color=col, marker=mk,
               edgecolor="white", linewidth=1.0, zorder=3, alpha=0.95)
offsets = {"crystal":(8,6),"flame":(8,-4),"star":(-10,10),"cell (metabolic)":(8,-10),
           "neural (small-world)":(8,8),"ecosystem":(-20,10),"galaxy":(8,4),"planet":(8,-6)}
for name, vif, drag, ss, computed, blurb in rows:
    col = "#c0392b" if name=="star" else ("#2c6fbb" if computed else "#95a5a6")
    ax.annotate(name, (vif,drag), textcoords="offset points", xytext=offsets.get(name,(6,4)),
                fontsize=7, color=col, fontweight=("bold" if name=="star" else "normal"))
ax.set_xlabel("inferential blur  —  max per-component VIF  (parts unattributable)")
ax.set_ylabel("interventional blur  —  max do(edge) drag  (edges inseparable)")
ax.set_title("Where persisters sit in the resolvability plane\n"
             "dense global coupling (star) blurs both ways; sparse/modular blurs one way; weak coupling stays sharp", loc="left")
ax.axvspan(1.0, 1.1, color="#2ecc71", alpha=0.06)
ax.text(1.02, ax.get_ylim()[1]*0.02+0.2, "sharp mask\n(flame, planet)", fontsize=6.5, color="#27ae60", va="bottom")
ax.text(3.0, 5.0, "resolvability trough\n(dense global coupling)", fontsize=6.5, color="#c0392b", ha="center")
from matplotlib.lines import Line2D
leg=[Line2D([0],[0],marker='o',color='w',markerfacecolor="#c0392b",markersize=8,label="star (focal)"),
     Line2D([0],[0],marker='o',color='w',markerfacecolor="#2c6fbb",markersize=7,label="computed placement"),
     Line2D([0],[0],marker='D',color='w',markerfacecolor="#95a5a6",markersize=7,label="argued placement")]
ax.legend(handles=leg, frameon=False, fontsize=6.5, loc="lower right")
ax.margins(0.14)
fig.tight_layout()
fig.savefig("aop_persister_resolvability_map.png", dpi=200, bbox_inches="tight")
for txt in list(ax.texts):
    if txt.get_text().startswith("sharp mask"):
        txt.set_position((1.02, 6.2)); txt.set_va("top")
fig.savefig("aop_persister_resolvability_map.png", dpi=200, bbox_inches="tight")