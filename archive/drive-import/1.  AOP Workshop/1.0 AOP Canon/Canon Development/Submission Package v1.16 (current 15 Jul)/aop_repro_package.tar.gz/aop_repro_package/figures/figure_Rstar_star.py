# skill:figure-style kernel.py (auto-injected on skill load)
META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


def panel_letter(ax, letter, dx=-0.18, dy=1.02, case="lower", fontsize=None):
    import matplotlib.pyplot as plt
    if fontsize is None:
        fontsize = plt.rcParams.get("font.size", 8) + 1
    s = letter.lower() if case == "lower" else letter.upper()
    ax.text(dx, dy, s, transform=ax.transAxes,
            fontweight="bold", fontsize=fontsize, va="bottom", ha="left")


import numpy as np
import matplotlib as mpl, matplotlib.pyplot as plt
apply_figure_style()

n = 6
rho = np.linspace(0.0, 0.97, 400)
sqrt_vif = np.sqrt((1+(n-2)*rho)/((1-rho)*(1+(n-1)*rho)))   # parts blur
cf       = 1/np.sqrt(1-rho)                                  # closed form guide
agg_unc  = 1/np.sqrt(1+(n-1)*rho)                            # whole sharpens (1/√λmax)
tc       = -0.5*((n-1)*np.log(1-rho)+np.log(1+(n-1)*rho))    # Integration (total correlation)

PARTS = "#c0392b"   # red = per-component (parts)
WHOLE = "#2c6fbb"   # blue = aggregate (whole)

fig, (axL, axR) = plt.subplots(1, 2, figsize=(11, 4.2))

# ---- Panel (a): vs coupling ρ ----
axL.plot(rho, sqrt_vif, color=PARTS, lw=2.4, label=r"per-shell attribution unc. $\sqrt{\mathrm{VIF}}$ (parts)")
axL.plot(rho, cf, color=PARTS, lw=1.2, ls="--", alpha=0.7, label=r"closed form $1/\sqrt{1-\rho}$")
axL.set_xlabel(r"inter-shell coupling  $\rho$  (equicorrelation)")
axL.set_ylabel(r"per-shell uncertainty  $\sqrt{\mathrm{VIF}}$", color=PARTS)
axL.tick_params(axis="y", labelcolor=PARTS)
axL.set_ylim(0.9, sqrt_vif.max()*1.05)
axLt = axL.twinx()
axLt.plot(rho, agg_unc, color=WHOLE, lw=2.4, label=r"aggregate-direction unc. $1/\sqrt{\lambda_{\max}}$ (whole)")
axLt.set_ylabel(r"aggregate uncertainty  $1/\sqrt{\lambda_{\max}}$", color=WHOLE)
axLt.tick_params(axis="y", labelcolor=WHOLE)
axLt.set_ylim(0.35, 1.02)
axL.set_title("(a) parts blur as shells couple, whole sharpens", loc="left")
# combined legend in whitespace
ln = axL.get_lines()+axLt.get_lines()
axL.legend(ln, [l.get_label() for l in ln], frameon=False, fontsize=6, loc="upper center")

# ---- Panel (b): vs Integration (TC) ----
axR.plot(tc, sqrt_vif, color=PARTS, lw=2.4, label=r"per-shell $\sqrt{\mathrm{VIF}}$ (parts)")
axR.set_xlabel("Integration  (total correlation, nats)")
axR.set_ylabel(r"per-shell uncertainty  $\sqrt{\mathrm{VIF}}$", color=PARTS)
axR.tick_params(axis="y", labelcolor=PARTS)
axR.set_ylim(0.9, sqrt_vif.max()*1.05)
axRt = axR.twinx()
axRt.plot(tc, agg_unc, color=WHOLE, lw=2.4, label=r"aggregate $1/\sqrt{\lambda_{\max}}$ (whole)")
axRt.set_ylabel(r"aggregate uncertainty  $1/\sqrt{\lambda_{\max}}$", color=WHOLE)
axRt.tick_params(axis="y", labelcolor=WHOLE)
axRt.set_ylim(0.35, 1.02)
axR.set_title("(b) the same pairing, vs Integration", loc="left")
axR.annotate("shells lock\n"+r"$\rho\to1$", xy=(tc[-1], sqrt_vif[-1]), xytext=(tc[-1]*0.62, sqrt_vif.max()*0.9),
             color=PARTS, fontsize=6.5, ha="center",
             arrowprops=dict(arrowstyle="->", color=PARTS, lw=1))
ln2 = axR.get_lines()+axRt.get_lines()
axR.legend(ln2, [l.get_label() for l in ln2], frameon=False, fontsize=6, loc="center right")

panel_letter(axL, 'a'); panel_letter(axR, 'b')
fig.suptitle(r"The star drives itself into the §6 resolvability trough  ($n=6$ shells, equicorrelation, closed-form)",
             fontsize=9)
fig.tight_layout(rect=[0,0,1,0.96])
fig.savefig("aop_star_resolvability.png", dpi=200, bbox_inches="tight")