import os as _os
_HERE=_os.path.dirname(_os.path.abspath(__file__))
# skill:figure-style kernel.py (auto-injected on skill load)
META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


def panel_letter(ax, letter, dx=-0.18, dy=1.02, case="lower", fontsize=None):
    import matplotlib.pyplot as plt
    if fontsize is None:
        fontsize = plt.rcParams.get("font.size", 8) + 1
    s = letter.lower() if case == "lower" else letter.upper()
    ax.text(dx, dy, s, transform=ax.transAxes,
            fontweight="bold", fontsize=fontsize, va="bottom", ha="left")


import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

d = np.load(_os.path.join(_HERE,"..","data","topology_curves.npz"))
gs = d["gs"]

apply_figure_style()

names = ["mean-field\n(all-to-all)","chain\n(nearest-nbr)","lattice\n(2D grid)","modular\n(4 blocks)","sparse\n(scale-free)"]
short = {n:n.replace("\n"," ") for n in names}
cmap = {"mean-field\n(all-to-all)":"#7f8fa6","chain\n(nearest-nbr)":"#c0392b","lattice\n(2D grid)":"#27ae60",
        "modular\n(4 blocks)":"#8e44ad","sparse\n(scale-free)":"#e67e22"}

fig, axs = plt.subplots(1, 3, figsize=(13.5, 4.3))
a,b,c = axs
for nm in names:
    col=cmap[nm]
    a.plot(gs, d[f"{nm}__vmax"], color=col, lw=1.9)
    b.plot(gs, d[f"{nm}__drag"], color=col, lw=1.9)
for nm in names:
    b.text(gs[-1]*1.01, d[f"{nm}__drag"][-1], short[nm].split(" (")[0], color=cmap[nm], fontsize=6.5, va="center")
a.set_xlabel("global coupling  g"); a.set_ylabel("max per-component VIF")
a.set_title("(a) inferential blur:\nattribution variance vs coupling", loc="left"); a.set_xlim(gs[0], gs[-1]*1.28)
b.set_xlabel("global coupling  g"); b.set_ylabel("max interventional drag")
b.set_title("(b) interventional blur:\ndo(edge) drag vs coupling", loc="left"); b.set_xlim(gs[0], gs[-1]*1.28)
gi = np.argmin(np.abs(gs-4.0))
for nm in names:
    c.scatter(d[f"{nm}__vmax"][gi], d[f"{nm}__drag"][gi], color=cmap[nm], s=70, zorder=3, edgecolor="white", linewidth=0.8)
    c.annotate(short[nm].split(" (")[0], (d[f"{nm}__vmax"][gi], d[f"{nm}__drag"][gi]),
               textcoords="offset points", xytext=(6,4), fontsize=6.5, color=cmap[nm])
c.set_xlabel("inferential blur (VIF_max)"); c.set_ylabel("interventional drag_max")
c.set_title("(c) the two mechanisms rank\ntopologies differently  (g=4)", loc="left"); c.margins(0.2)
for ax,l in zip(axs,"abc"): panel_letter(ax,l)
fig.suptitle("The §6 resolvability limit is a family indexed by coupling topology "
             "(aggregate/whole load-bearing in every case: var = 1.000)", fontsize=8.5)
fig.tight_layout(rect=[0,0,1,0.95])
fig.savefig("aop_topology_resolvability.png", dpi=200, bbox_inches="tight")

r=fig.canvas.get_renderer()
tl=set().union(*[set(ax.get_xticklabels()+ax.get_yticklabels()) for ax in fig.axes])
at=set(ax.yaxis.label for ax in fig.axes)|set(ax.xaxis.label for ax in fig.axes)
texts=[(t,t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
ov=[(a_.get_text(),b_.get_text()) for i,(a_,ba) in enumerate(texts) for b_,bb in texts[i+1:]
    if ba.overlaps(bb) and not(a_ in tl and b_ in tl) and not(a_ in at and b_ in tl) and not(b_ in at and a_ in tl)]

# remove b end-labels (redundant; color-threaded); stagger a harder
for txt in list(b.texts): txt.remove()
for txt in list(a.texts): txt.remove()
ends = {nm: float(d[f"{nm}__vmax"][-1]) for nm in names}
order = sorted(names, key=lambda n: ends[n])
ypos={}; prev=-9
for nm in order:
    y=ends[nm]
    if y-prev < 0.09: y=prev+0.09
    ypos[nm]=y; prev=y
for nm in names:
    a.text(gs[-1]*1.015, ypos[nm], short[nm].split(" (")[0], color=cmap[nm], fontsize=6.5, va="center")
fig.savefig("aop_topology_resolvability.png", dpi=200, bbox_inches="tight")

r=fig.canvas.get_renderer()
tl=set().union(*[set(ax.get_xticklabels()+ax.get_yticklabels()) for ax in fig.axes])
at=set(ax.yaxis.label for ax in fig.axes)|set(ax.xaxis.label for ax in fig.axes)
texts=[(t,t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
ov=[(a_.get_text(),b_.get_text()) for i,(a_,ba) in enumerate(texts) for b_,bb in texts[i+1:]
    if ba.overlaps(bb) and not(a_ in tl and b_ in tl) and not(a_ in at and b_ in tl) and not(b_ in at and a_ in tl)]

# find and re-place the modular & lattice annotations in panel c
for txt in list(c.texts):
    if txt.get_text() in ("modular","lattice"):
        txt.remove()
pts = {nm:(float(d[f"{nm}__vmax"][gi]), float(d[f"{nm}__drag"][gi])) for nm in names}
c.annotate("modular", pts["modular\n(4 blocks)"], textcoords="offset points", xytext=(4,7), fontsize=6.5, color=cmap["modular\n(4 blocks)"])
c.annotate("lattice", pts["lattice\n(2D grid)"], textcoords="offset points", xytext=(6,-9), fontsize=6.5, color=cmap["lattice\n(2D grid)"])
fig.savefig("aop_topology_resolvability.png", dpi=200, bbox_inches="tight")