# The Architecture of Persistence (AOP) — Reproducibility Package

This repository regenerates every computed result and figure in *The Architecture of
Persistence* (Royal Society *Interface Focus*, Perspective). AOP asks what it takes for a
region of reality to **persist** — to resist erasure — and answers with four entropic axes
(Boundary, Drive, Memory, Integration), a two-layer object (a syntactic coupling graph and a
semantic mask read out by a system's own viability), and a set of pre-registered refusals.
Every computed claim in the paper is **closed-form or cheap-numerical**, not estimated, by
design; the scripts here are short and self-contained, and each maps to exactly one paper
display item or numerical statement.

## Layout

```
aop_repro_package/
├── engine/     the core closed-form resolvability / VIF signature engine
├── gates/      the five pre-registered cross-brick gate modules (4 NULLs + 1 GO)
├── figures/    one script per paper figure
├── data/       deposited data files (verdict JSON, precomputed sweep arrays)
└── MANIFEST    figure/result → script → expected-output table (also below)
```

## Requirements

Python ≥ 3.10 with `numpy`, `scipy`, `pandas`, `matplotlib`. No GPU, no network, no external
data. Every script runs in seconds on a laptop.

```bash
python -m pip install numpy scipy pandas matplotlib
```

## How to run

Each script prints its key computed numbers to stdout. Most figure scripts also write their PNG
to the current working directory when executed; two — `figure_LT.py` and `figure_LT_threshold.py`
— regenerate the computation behind their figure and print the verdict to stdout only (no PNG), as
marked in the MANIFEST table below. Run any of them directly:

```bash
# engine smoke test (no figure) — validates against the equicorrelation closed forms
python -c "import importlib.util as u; s=u.spec_from_file_location('e','engine/aop_resolvability_engine.py'); m=u.module_from_spec(s); s.loader.exec_module(m); print(sorted(m.resolvability_signature.__doc__ is not None and ['ok']))"

# a figure / a computed verdict
python figures/figure_LT.py                 # prints the living-threshold classification to stdout
python figures/figure_MW_worked_mask.py     # computes the mask AND saves the PNG panel

# a gate (verdict printed to stdout)
python gates/aop_individuation_gate.py      # -> C1..C5 all True  (the individuation GO)
python gates/break_ecmu.py                  # -> the E-vs-Cμ kill-test (the retracted→NULL)
```

Scripts are written to be **run from the package root or from their own subdirectory** — the
engine- and data-dependent figures resolve `../engine` and `../data` relative to their own
file location, and the gate modules that import their siblings prepend their own directory to
`sys.path`.

## MANIFEST — paper display item / result → script → expected output

Figure labels follow the canon (v1.16) and the submission blueprint's renumber map
(new main-text number in parentheses where it differs).

| Paper item | Result reproduced | Script | Expected output |
|---|---|---|---|
| **Fig R** (main Fig 3a) | Resolvability plane: where persisters sit; dense global coupling (the star) blurs both inferential and interventional axes | `figures/figure_R_resolvability_map.py` | `aop_persister_resolvability_map.png` + stdout placements; uses `engine/` + `data/persister_rows.pkl` |
| **Fig R★** (main Fig 3b) | The star drives *itself* into the §6 resolvability trough (n=6 shells, equicorrelation, closed-form; validated vs 1/√(1−ρ) and 1/√λ_max) | `figures/figure_Rstar_star.py` | `aop_star_resolvability.png` |
| **Fig TF** (main Fig 4) | Resolvability limit as a topology-indexed **family**: inferential and interventional blur rank topologies differently; aggregate stays load-bearing (var=1.000) | `figures/figure_TF_topology_family.py` | `aop_topology_resolvability.png`; uses `data/topology_curves.npz` |
| **Fig LT** (main Fig 5) | The living threshold: alive = load-bearing ∧ decoupled; cell-type ALIVE, star correctly excluded | `figures/figure_LT.py` | **stdout only** — prints the per-system classification (cell ALIVE; star coupling and star intrinsic both outside). The published Figure LT was drawn from these numbers; the deposited script regenerates the underlying computation, not the rendered PNG. Reference data in `data/figure_LT_data.json` |
| **Fig LT-T** (Fig S6 / Fig 5 inset) | Living threshold is architectural, not a timescale-separation magnitude (no knee across the star–cell window) | `figures/figure_LT_threshold.py` | **stdout only** — prints the timescale-ratio sweep (weights, monotonicity flag) and the architecture contrast (cell arch=1, star arch=0). Regenerates the computation behind the figure, not the rendered PNG |
| **Fig MW** (main Fig 6) | Semantic mask computed on the Figure DM driven ring: graded per-edge weights (interval across three viability functionals), exactly zero on an inert spectator | `figures/figure_MW_worked_mask.py` | `figure_MW_worked_mask.png` |
| **Fig DM** (Fig S4) | D→M memory floor: σ>0 ⇒ E>0; converse fails (detailed-balance oscillator has σ=0, E>0) | `figures/figure_DM_memory_floor.py` | `aop_DM_memory_floor.png` |
| **Fig T** (Fig S5) | The non-energy triangle (B–M, M–I, B–I) reachability scan over 4000 random VAR(1) systems | `figures/figure_T_nonenergy_triangle.py` | `aop_nonenergy_triangle.png` |
| **Fig 2 / integration trade-off** (Fig S1) | Mask-resolvability × Integration trade-off: per-component weight blurs, aggregate sharpens | `figures/figure_integration_tradeoff.py` | `aop_integration_resolvability.png` |
| **§10 numerical statement** | Invariant-mass / binding check underlying the domain-edge argument | (analytic; stated in caption, no standalone figure) | — |

### The gate ledger (Table 4) — five pre-registered cross-brick gates

Each gate was frozen before computation, with two exits only (the pre-registered claim, or a
scoped NULL). Four returned NULL; the individuation gate — run in the opposite direction, to
establish a *new* axis — returned the register's first GO.

| Gate (Table 4) | Object tested | Outcome | Script | Data file |
|---|---|---|---|---|
| Resolvability ↔ TUR, **trajectory-B** | drift/trajectory Fisher information of the driven generator | NULL | `gates/aop_trajectory_fim.py` | `data/aop_gate0b_trajectory_arrays.npz` |
| Resolvability ↔ TUR, **trajectory-K** | nuisance-robust Fisher info F_K\|Q for the coupling partition, drive co-estimated (constrained floor rose ~3×, but trivial K=I control rose ~10× — a drift-map scale artifact) | NULL | `gates/aop_trajectoryK_fim.py` | `data/kgate_floors.json` |
| **E vs Cμ dormancy screen** | causal irreversibility Ξ=Cμ⁺−Cμ⁻ vs σ̇ at fixed structure; the GO→retracted→NULL that caught a mislabeled entropy-production rate | NULL | `gates/aop_ecmu_screen.py` + `gates/break_ecmu.py` (kill-test) | `data/ecmu_screen.json`, `data/ecmu_killtest.json` |
| **Individuation axis, Φ_MIP** (opposite direction) | whether Φ_MIP on Σ=(I+gL)⁻¹ is a graded one-vs-many axis distinct from resolvability (VIF) and Integration (TC) — five criteria | **GO** | `gates/aop_individuation_gate.py` (+ `gates/aop_individuation_check.py`) | — |

*Note on the fourth NULL.* The canon's Table 4 lists a **Resolvability ↔ TUR, snapshot** gate
(static conditioning of Σ⁻¹ vs σ̇). That gate is the Q=0 limit of the resolvability engine
itself: it is the statement, proven analytically in `engine/aop_resolvability_engine.py`, that
the resolvability signature is a functional of the time-symmetric Σ while σ̇ lives in the
antisymmetric current — Σ is Lyapunov-invariant to the drive. The trajectory-B and trajectory-K
modules extend that snapshot result to the driven (Q≠0) regime. All four NULLs share one
positive finding: the **reversible/irreversible sector split**.

## Provenance

The engine and the three deposited figure scripts (`figure_LT`, `figure_LT_threshold`,
`figure_MW_worked_mask`) and the five gate modules were deposited as standalone scripts during
development. The remaining engine-derived figure scripts (`figure_R`, `figure_Rstar`,
`figure_TF`, `figure_T`, `figure_DM`, `figure_integration_tradeoff`) were recovered verbatim
from the producing-cell code of each deposited figure; absolute artifact-store paths in the
recovered code were rewritten to package-relative paths, and nothing else was changed.

## License

Deposited under an open licence (to be specified at submission — CC BY 4.0 for text/data,
MIT for code, unless the journal requires otherwise).
