
"""AOP resolvability-signature engine.
A system's coupling topology is a graph; its resolvability signature is read from the
covariance Sigma = (I + g*L)^{-1}, where L is the graph Laplacian and g the global coupling knob.
All quantities closed-form / cheap-numerical. See aop_resolvability_engine tests for validation.
"""
import numpy as np

def sigma_from_laplacian(L, g):
    """Covariance from a coupling Laplacian L at global coupling g:  Sigma = (I + g L)^{-1}."""
    n = L.shape[0]
    return np.linalg.inv(np.eye(n) + g * L)

def resolvability_signature(Sigma):
    """Resolvability signature of a system given its component covariance Sigma.
    Returns a dict of the quantities that decide whether the mask can resolve parts vs whole."""
    n = Sigma.shape[0]
    Sinv = np.linalg.inv(Sigma)
    d = np.diag(Sigma).copy()                       # marginal variances
    # --- spectrum (stiff/sloppy structure of the whole) ---
    ev = np.sort(np.linalg.eigvalsh(Sigma))[::-1]   # descending
    lam_max, lam_min = ev[0], ev[-1]
    # participation ratio of the spectrum: 1 => one mode dominates (degenerate/mean-field-like),
    # ~n => spread evenly. (PR on eigenvalues as a spectral-shape descriptor.)
    p = ev / ev.sum()
    spectral_PR = 1.0 / np.sum(p**2)
    # --- INFERENTIAL blur (parts): VIF_i = Sigma_ii * (Sigma^{-1})_ii ---
    vif = d * np.diag(Sinv)
    # --- INTERVENTIONAL blur (parts): row off-diagonal drag of a do(x_i) intervention ---
    # do(x_i=a) shifts x_j by Sigma_ji/Sigma_ii; total drag on the rest = sum_{j!=i} |Sigma_ji|/Sigma_ii
    A = np.abs(Sigma) / d[:, None]
    np.fill_diagonal(A, 0.0)
    drag = A.sum(axis=1)
    # --- the WHOLE: variance of the conserved/aggregate (constant) direction ---
    ones = np.ones(n) / np.sqrt(n)
    agg_var = float(ones @ Sigma @ ones)            # variance of the mean/collective (conserved) mode
    return dict(
        n=n, eigs=ev, lam_max=lam_max, lam_min=lam_min,
        stiff_sloppy_ratio=lam_max/lam_min, spectral_PR=spectral_PR,
        vif=vif, vif_max=float(vif.max()), vif_gmean=float(np.exp(np.mean(np.log(vif)))),
        drag=drag, drag_max=float(drag.max()), drag_mean=float(drag.mean()),
        agg_var=agg_var,
    )

# --- named topologies as Laplacians ---
def L_complete(n):
    L = -np.ones((n, n)); np.fill_diagonal(L, n - 1.0); return L
def L_path(n):
    L = np.zeros((n, n))
    for i in range(n - 1):
        L[i, i] += 1; L[i+1, i+1] += 1; L[i, i+1] -= 1; L[i+1, i] -= 1
    return L
def L_grid(r, c):
    n = r * c; L = np.zeros((n, n))
    idx = lambda a, b: a * c + b
    for a in range(r):
        for b in range(c):
            for da, db in [(1,0),(0,1)]:
                a2, b2 = a+da, b+db
                if a2 < r and b2 < c:
                    i, j = idx(a,b), idx(a2,b2)
                    L[i,i]+=1; L[j,j]+=1; L[i,j]-=1; L[j,i]-=1
    return L
def L_modular(n_mod, per_mod, p_out=0.05, seed=0):
    rng = np.random.default_rng(seed)
    n = n_mod * per_mod; A = np.zeros((n, n))
    for m in range(n_mod):
        s = m*per_mod
        A[s:s+per_mod, s:s+per_mod] = 1.0            # dense within module
    A[np.triu_indices(n,1)] = np.where(A[np.triu_indices(n,1)]>0, 1.0,
                                       (rng.random(len(np.triu_indices(n,1)[0]))<p_out).astype(float))
    A = np.triu(A,1); A = A + A.T; np.fill_diagonal(A,0)
    L = np.diag(A.sum(1)) - A; return L
def L_sparse_ba(n, m=2, seed=0):
    # Barabasi-Albert-ish preferential attachment -> scale-free degree
    rng = np.random.default_rng(seed)
    A = np.zeros((n, n)); deg = np.zeros(n)
    for i in range(1, n):
        k = min(m, i)
        if deg[:i].sum() == 0:
            targets = rng.choice(i, size=k, replace=False)
        else:
            pr = deg[:i]/deg[:i].sum()
            targets = rng.choice(i, size=k, replace=False, p=pr)
        for j in targets:
            A[i,j]=1; A[j,i]=1; deg[i]+=1; deg[j]+=1
    L = np.diag(A.sum(1)) - A; return L
