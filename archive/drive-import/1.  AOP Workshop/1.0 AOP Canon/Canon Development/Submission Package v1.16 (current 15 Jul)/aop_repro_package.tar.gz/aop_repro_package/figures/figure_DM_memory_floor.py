import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.text
import numpy as np
import pandas as pd

# skill:figure-style kernel.py (auto-injected on skill load)
META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


def panel_letter(ax, letter, dx=-0.18, dy=1.02, case="lower", fontsize=None):
    import matplotlib.pyplot as plt
    if fontsize is None:
        fontsize = plt.rcParams.get("font.size", 8) + 1
    s = letter.lower() if case == "lower" else letter.upper()
    ax.text(dx, dy, s, transform=ax.transAxes,
            fontweight="bold", fontsize=fontsize, va="bottom", ha="left")


def stationary(P):
    w, v = np.linalg.eig(P.T)
    i = np.argmin(np.abs(w - 1))
    pi = np.real(v[:, i])
    pi = pi / pi.sum()
    return pi


def entropy_production_per_step(P, pi):
    s = 0.0
    n = len(pi)
    for i in range(n):
        for j in range(n):
            f = pi[i] * P[i, j]
            r = pi[j] * P[j, i]
            if f > 0 and r > 0:
                s += f * np.log(f / r)
    return s


def excess_entropy_markov1(P, pi):
    E = 0.0
    n = len(pi)
    for i in range(n):
        for j in range(n):
            if P[i, j] > 0 and pi[j] > 0:
                E += pi[i] * P[i, j] * np.log(P[i, j] / pi[j])
    return E


def ring3(p, r):
    s = 1 - p - r
    P = np.zeros((3, 3))
    for i in range(3):
        P[i, (i + 1) % 3] = p
        P[i, (i - 1) % 3] = r
        P[i, i] = s
    return P


rows = []
for p in np.linspace(0.05, 0.6, 23):
    r = 0.65 - p
    if r <= 0.01 or (1 - p - r) < 0:
        continue
    P = ring3(p, r)
    pi = stationary(P)
    sig = entropy_production_per_step(P, pi)
    E = excess_entropy_markov1(P, pi)
    rows.append((p, r, np.log(p / r), sig, E))

d = pd.DataFrame(rows, columns=["p", "r", "drive_ln(p/r)", "sigma", "E"])

eps = 1e-9
d["sigma_pos"] = d.sigma > eps
d["E_pos"] = d.E > eps

# K1 coarse-graining demo
P_ring = ring3(0.55, 0.10)
pi_ring = stationary(P_ring)
sig_hidden = entropy_production_per_step(P_ring, pi_ring)
E_full_Y = excess_entropy_markov1(P_ring, pi_ring)

apply_figure_style()
SIG_C = "#c1440e"
MEM_C = META_GREY

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.2))

dv = d["drive_ln(p/r)"].values
sg = d.sigma.values
E = d.E.values
order = np.argsort(dv)
ax1.plot(dv[order], sg[order], '-', color=SIG_C, lw=1.8, label='σ  (entropy production)')
ax1.plot(dv[order], E[order], '-', color=MEM_C, lw=1.8, label='E = I(past; future)')
ax1.axvline(0, color='0.85', lw=0.8, zorder=0)
ax1.scatter([0], [d[d.sigma < 1e-9].E.values[0]], s=26, color=MEM_C, zorder=5)
ax1.annotate('detailed balance:\nσ=0 yet E>0\n(memory is free)', xy=(0, 0.02),
             xytext=(0.42, 0.60), fontsize=6, ha='left', xycoords=('data', 'axes fraction'),
             textcoords='axes fraction',
             arrowprops=dict(arrowstyle='->', lw=0.7, color='0.5'))
ax1.set_xlabel('Drive  (log forward/reverse rate ratio)')
ax1.set_ylabel('nats / step')
ax1.set_title('σ > 0 forces E > 0; converse fails', fontsize=8, loc='left')
ax1.legend(frameon=False, fontsize=6, loc='upper center')
ax1.margins(0.04)

labels = ['full state\n(σ read here)', 'coarse-grained\nobservable']
sig_vals = [sig_hidden, 0.0]
E_vals = [E_full_Y, 0.0]
x = np.arange(2)
w = 0.36
ax2.bar(x - w / 2, sig_vals, w, color=SIG_C, label='σ')
ax2.bar(x + w / 2, E_vals, w, color=MEM_C, label='E')
ax2.text(1, 0.012, 'both 0', ha='center', fontsize=6, color='0.4')
ax2.set_xticks(x)
ax2.set_xticklabels(labels, fontsize=6)
ax2.set_ylabel('nats / step')
ax2.set_title('Scope limit: read σ and E on one description', fontsize=8, loc='left')
ax2.legend(frameon=False, fontsize=6, loc='upper right')
ax2.margins(0.04)
ax2.set_ylim(0, max(sig_vals) * 1.25)
ax2.annotate('coarse-graining hides current\nAND memory together',
             xy=(1, 0.02), xytext=(0.30, 0.60), fontsize=6, xycoords=('data', 'axes fraction'),
             textcoords='axes fraction',
             arrowprops=dict(arrowstyle='->', lw=0.7, color='0.5'))

panel_letter(ax1, 'a')
panel_letter(ax2, 'b')
fig.tight_layout()
fig.savefig("aop_DM_memory_floor.png", dpi=300, bbox_inches='tight')