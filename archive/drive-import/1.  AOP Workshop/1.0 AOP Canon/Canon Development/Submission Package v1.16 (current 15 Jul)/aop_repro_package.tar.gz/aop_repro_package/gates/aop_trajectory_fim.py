"""
aop_trajectory_fim.py — Gate 0b-trajectory read-out.

Adds the driven-regime (Q != 0) resolvability lens to the deposited snapshot engine
(aop_resolvability_engine.py). For an OU persister dx = -B x dt + sqrt(2D) dW with
stationary covariance Sigma and drift B = (D + Q) Sigma^-1 (Q antisymmetric), the
continuous-observation Fisher information for the entries of the drift matrix B is

    F_traj = T * ( (2D)^-1  kron  Sigma )                                  (Eq. TF1)

verified against the OU Girsanov likelihood, Larédo, "Statistical inference for
epidemic processes", arXiv:2004.07688, eq. (1.2.9): scalar case
L_T(theta) = exp( (theta/sigma^2) int xi dxi - (theta^2/2 sigma^2) int xi^2 dt ),
whose Fisher information is (1/sigma^2) int E[xi^2] dt = (T/sigma^2) E[xi^2_stat];
the multivariate drift-entry generalization is the Kronecker form above (the score
d/dB_{ij} sees only the equal-time second moment Sigma).

Q=0 -> snapshot lens (Sigma-based VIF, deposited engine); Q!=0 -> this lens.
Both coexist; the engine switches at the drive axis.
"""
import numpy as np

def ou_drift(Sigma, D, Q):
    """B = (D + Q) Sigma^-1 solving the Lyapunov eq B Sigma + Sigma B^T = 2D."""
    return (D + Q) @ np.linalg.inv(Sigma)

def sigma_dot(Sigma, D, Q):
    """Mean entropy production rate Tr(D^-1 Q Sigma^-1 Q^T)."""
    return float(np.trace(np.linalg.inv(D) @ Q @ np.linalg.inv(Sigma) @ Q.T))

def F_traj(Sigma, D, T=1.0):
    """Continuous-observation drift-entry Fisher information, Eq. TF1. Q-free by construction."""
    return T * np.kron(np.linalg.inv(2*D), Sigma)

def traj_conditioning(Sigma, D, T=1.0):
    """Stiff/sloppy eigenvalue ratio of F_traj (trajectory resolvability signature)."""
    w = np.linalg.eigvalsh(F_traj(Sigma, D, T))
    w = w[w > 1e-14]
    return float(w.max()/w.min())

def antisym_from_upper(n, amp, seed=0):
    """A fixed antisymmetric circulation pattern scaled by amp."""
    rng = np.random.default_rng(seed)
    A = rng.standard_normal((n, n))
    Q = np.triu(A, 1); Q = Q - Q.T
    nrm = np.linalg.norm(Q)
    return amp * Q / (nrm if nrm > 0 else 1.0)
