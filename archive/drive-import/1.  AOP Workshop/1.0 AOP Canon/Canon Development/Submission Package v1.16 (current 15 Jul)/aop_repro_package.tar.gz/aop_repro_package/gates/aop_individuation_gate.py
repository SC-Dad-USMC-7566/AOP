"""AOP individuation gate (Gaussian, Option 1) — the five frozen criteria.
Pre-registration: aop_individuation_gate_prereg.md. Verdict: aop_individuation_gate_verdict.md.
Object: Phi-irreducibility = Gaussian MI across the minimum information partition of Sigma=(I+gL)^-1.
Builds on aop_individuation_check.py (phi_MIP, L_two_modules, L_k_modules, total_correlation).

RESULT: GO on all five (C1,C5 exact; C2,C3,C4 robust). See verdict.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
from aop_individuation_check import phi_MIP, L_two_modules, L_k_modules, total_correlation

def sigma(L,g): n=L.shape[0]; return np.linalg.inv(np.eye(n)+g*L)
def corr(S): d=np.sqrt(np.diag(S)); return S/np.outer(d,d)
def max_vif(S): R=corr(S); return float(np.max(np.diag(np.linalg.inv(R))))
def total_edge_weight(L): return float(np.abs(L-np.diag(np.diag(L))).sum()/2)
def L_ring(n):
    L=np.zeros((n,n))
    for i in range(n): L[i,(i+1)%n]=L[(i+1)%n,i]=-1
    for i in range(n): L[i,i]=-(L[i].sum())
    return L

# C1 zero-calibration: block-decomposable -> Phi==0 for ALL within-block richness.
def C1(grid_k=(2,3,4),grid_per=(2,3),grid_win=(0.3,1.0,3.0,8.0),grid_g=(1.0,3.0)):
    fails=[(k,per,w,g,phi_MIP(sigma(L_k_modules(k,per,w,0.0),g)))
           for k in grid_k for per in grid_per for w in grid_win for g in grid_g
           if abs(phi_MIP(sigma(L_k_modules(k,per,w,0.0),g)))>1e-10]
    return len(fails)==0, fails

# C2 gradedness: monotone Phi 0->whole along many->one weld.
def C2(grid_k=(2,3,4),grid_per=(2,3),grid_g=(1.0,3.0),ws=None):
    ws=np.linspace(0,1.0,11) if ws is None else ws
    fails=[]
    for k in grid_k:
        for per in grid_per:
            for g in grid_g:
                ph=[phi_MIP(sigma(L_k_modules(k,per,1.0,w),g)) for w in ws]
                if not all(ph[i+1]>=ph[i]-1e-9 for i in range(len(ph)-1)): fails.append((k,per,g))
    return len(fails)==0, fails

# C4 matched-budget trivial-structure control: one integrated whole Phi>0, k independent Phi=0 at equal budget.
def C4(g=3.0):
    L_one=L_ring(6); L_many=L_k_modules(2,3,1.0,0.0)
    L_one_s=L_one*(total_edge_weight(L_many)/total_edge_weight(L_one))
    return (phi_MIP(sigma(L_one_s,g)), phi_MIP(sigma(L_many,g)))

# C3 irreducibility to (VIF, TC): (a) opposite-movement under the weld; (b) a matched-(VIF,TC) pair
# with different Phi. Returns (pass_bool, detail).
def C3(g=3.0):
    # (a) opposite movement: low-w_out weld raises Phi while VIF and TC fall
    ws=[0.0,0.02,0.05,0.1]
    S=[sigma(L_two_modules(3,1.0,w),g) for w in ws]
    vif=[max_vif(s) for s in S]; tc=[total_correlation(s) for s in S]; ph=[phi_MIP(s) for s in S]
    opp = (vif[-1]<vif[0]) and (tc[-1]<tc[0]) and (ph[-1]>ph[0])
    # (b) matched (VIF,TC), different Phi: 2 indep modules (Phi=0) vs a weak-weld tuned to match
    S1=sigma(L_k_modules(2,3,1.0,0.0),g); v1,t1,p1=max_vif(S1),total_correlation(S1),phi_MIP(S1)
    best=None
    for wout in (0.05,0.1,0.15,0.2):
        for gg in np.linspace(0.2,12,400):
            s=sigma(L_two_modules(3,1.0,wout),gg); d=abs(max_vif(s)-v1)+abs(total_correlation(s)-t1)
            if best is None or d<best[0]: best=(d,wout,gg,max_vif(s),total_correlation(s),phi_MIP(s))
    matched = best[0]<0.15 and abs(best[5]-p1)>0.05
    return (opp and matched), dict(opp=opp, base=(v1,t1,p1), match=best)

# C5 coordinate well-posedness: individuation ordering invariant under per-coordinate rescaling.
# Gaussian MI is analytically rescaling-invariant, so Phi(Sigma)==Phi(corr) exactly; this checks it
# numerically under strong heterogeneity and confirms the ordering is preserved.
def C5(g=3.0, scales=(0.5,1.0,2.0,1.0,0.5,3.0)):
    scales=np.array(scales)
    systems={"2indep":L_k_modules(2,3,1.0,0.0),"weld0.05":L_two_modules(3,1.0,0.05),
             "weld0.2":L_two_modules(3,1.0,0.2),"ring6":L_ring(6)}
    def het(L): D=np.diag(scales); return D@sigma(L,g)@D
    phi_cov={k:phi_MIP(het(L)) for k,L in systems.items()}
    phi_corr={k:phi_MIP(corr(het(L))) for k,L in systems.items()}
    ord_cov=sorted(systems,key=lambda k:phi_cov[k]); ord_corr=sorted(systems,key=lambda k:phi_corr[k])
    exact=np.allclose(list(phi_cov.values()),list(phi_corr.values()))
    return (ord_cov==ord_corr and exact), dict(ord_cov=ord_cov, ord_corr=ord_corr, exact_equal=exact)

if __name__=="__main__":
    print("C1",C1()[0]); print("C2",C2()[0]); print("C3",C3()[0])
    one,many=C4(); print("C4", one>0.05 and abs(many)<1e-9, (round(one,4),round(many,4)))
    print("C5",C5()[0])
