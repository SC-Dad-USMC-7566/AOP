# skill:figure-style kernel.py (auto-injected on skill load)
META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


def panel_letter(ax, letter, dx=-0.18, dy=1.02, case="lower", fontsize=None):
    import matplotlib.pyplot as plt
    if fontsize is None:
        fontsize = plt.rcParams.get("font.size", 8) + 1
    s = letter.lower() if case == "lower" else letter.upper()
    ax.text(dx, dy, s, transform=ax.transAxes,
            fontweight="bold", fontsize=fontsize, va="bottom", ha="left")


import numpy as np
import pandas as pd

n = 6
rhos = np.linspace(0.0, 0.985, 60)

def equicorr(n, rho):
    R = np.full((n,n), rho); np.fill_diagonal(R, 1.0); return R

rows=[]
for rho in rhos:
    R = equicorr(n, rho)
    sign, logdet = np.linalg.slogdet(R)
    TC = -0.5*logdet
    Rinv = np.linalg.inv(R)
    VIF = np.diag(Rinv).mean()
    width_vif = np.sqrt(VIF)
    evals = np.linalg.eigvalsh(R)
    lam_min, lam_max = evals.min(), evals.max()
    width_sloppy = 1.0/np.sqrt(lam_min)
    sloppiness = lam_max/lam_min
    beta = np.ones(n)
    total_var = beta @ R @ beta
    others_var = np.array([ (np.delete(beta,i)) @ (np.delete(np.delete(R,i,0),i,1)) @ (np.delete(beta,i)) for i in range(n)])
    dropone = total_var - others_var
    firstin = np.ones(n)
    attribution_range = np.mean(np.abs(firstin - dropone))
    width_aggregate = 1.0/np.sqrt(lam_max)
    rows.append(dict(rho=rho, TC=TC, width_vif=width_vif, width_sloppy=width_sloppy,
                     sloppiness=sloppiness, attribution_range=attribution_range,
                     width_aggregate=width_aggregate, total_var=total_var, lam_min=lam_min, lam_max=lam_max))

df = pd.DataFrame(rows)

import matplotlib.pyplot as plt
apply_figure_style()
MULTI="#c1440e"; SLOPPY="#1f6f8b"; PID="#7b5aa6"; AGG="#3a3a3a"

fig,(ax1,ax2)=plt.subplots(1,2,figsize=(7.4,3.2))

ax1.plot(df.TC, df.width_vif,   color=MULTI, lw=1.9, label='per-weight: √VIF (multicollinearity)')
ax1.plot(df.TC, df.width_sloppy,color=SLOPPY, lw=1.9, ls=(0,(4,2)), label='per-weight: 1/√λ$_{min}$ (FIM sloppiness)')
ax1.plot(df.TC, df.width_aggregate, color=AGG, lw=1.9, label='aggregate (stiff direction)')
ax1.set_yscale('log')
ax1.set_xlabel('Integration  (total correlation, nats)')
ax1.set_ylabel('uncertainty in a weight  (×σ)')
ax1.set_title('A per-component weight blurs;\nthe aggregate sharpens', fontsize=8, loc='left')
ax1.legend(frameon=False, fontsize=5.6, loc='center left')
ax1.annotate('individual weights\ndiverge', xy=(df.TC.iloc[-8], df.width_vif.iloc[-8]),
             xytext=(0.30,0.80), textcoords='axes fraction', fontsize=6, color=MULTI,
             arrowprops=dict(arrowstyle='->',lw=0.7,color=MULTI))
ax1.annotate('aggregate\nstays sharp', xy=(df.TC.iloc[-8], df.width_aggregate.iloc[-8]),
             xytext=(0.42,0.13), textcoords='axes fraction', fontsize=6, color=AGG,
             arrowprops=dict(arrowstyle='->',lw=0.7,color=AGG))

ax2.plot(df.TC, df.attribution_range, color=PID, lw=1.9,
         label='attribution-order spread\n(PID / Shapley ambiguity)')
ax2.set_xlabel('Integration  (total correlation, nats)')
ax2.set_ylabel('per-weight ambiguity  (var. units)')
ax2.set_title('Third field, same signal:\nthe weight stops being one number', fontsize=8, loc='left')
ax2.legend(frameon=False, fontsize=6, loc='upper left')
ax2.margins(0.04)

for ax,l in [(ax1,'a'),(ax2,'b')]: panel_letter(ax,l)
fig.tight_layout()
fig.savefig("aop_integration_resolvability.png", dpi=300, bbox_inches='tight')