"""AOP individuation check (action B of the individuation handoff).
Decisive test: is AOP's resolvability signature (per-part VIF divergence, aggregate conserved)
the SAME object as Aguilera & Di Paolo's integrated information Phi (MIP-susceptibility), or different?

Aguilera M, Di Paolo EA. Integrated information in the thermodynamic limit.
Neural Networks 114, 136-146 (2019). doi:10.1016/j.neunet.2019.03.001 (arXiv:1806.07879, CC BY 4.0).
Key formalization (verified in PDF body, not abstract): "In the thermodynamic limit, we can
describe integrated information as the susceptibility of the system to changes in the direction of
the minimum information partition (MIP). Consequently, integrated information diverges when the
system is near a critical point."

AOP coupling model: Sigma = (I + g L)^{-1}, L a graph Laplacian, g the global coupling knob
(aop_resolvability_engine.py).
"""
import numpy as np, itertools

def gauss_MI_cut(Sigma, A, B):
    """Gaussian mutual information across bipartition (A,B): 0.5*log(detS_A detS_B / detS)."""
    sA=Sigma[np.ix_(A,A)]; sB=Sigma[np.ix_(B,B)]
    _,ld=np.linalg.slogdet(Sigma); _,ldA=np.linalg.slogdet(sA); _,ldB=np.linalg.slogdet(sB)
    return 0.5*(ldA+ldB-ld)

def phi_MIP(Sigma):
    """Phi as MI across the minimum information partition (least-disrupting normalized bipartition),
    the Gaussian analogue of Aguilera's MIP-based integrated information."""
    n=Sigma.shape[0]; idx=list(range(n)); best=np.inf; phi=None
    for k in range(1,n//2+1):
        for A in itertools.combinations(idx,k):
            A=list(A); B=[i for i in idx if i not in A]
            mi=gauss_MI_cut(Sigma,A,B); norm=mi/min(len(A),len(B))
            if norm<best: best=norm; phi=mi
    return phi

def L_two_modules(per=3, w_in=1.0, w_out=0.0):
    """Two fully-connected modules of `per` nodes; within-module weight w_in, between w_out."""
    n=2*per; W=np.zeros((n,n))
    for a in range(2):
        nodes=range(a*per,(a+1)*per)
        for i in nodes:
            for j in nodes:
                if i<j: W[i,j]=W[j,i]=w_in
    for i in range(per):
        for j in range(per,2*per):
            W[i,j]=W[j,i]=w_out
    return np.diag(W.sum(1))-W

# RESULT (see aop_individuation_check_verdict.md):
#  - Global coupling g up  -> VIF up AND Phi up  (shared input; the trap).
#  - Inter-module w_out 0->0.1 -> Phi UP (whole becomes irreducible) while VIF DOWN (parts less blurred).
#    Robust across per in {2,3,4} and g in {1,3,6}. => DIFFERENT objects. Gate NULL.
#  - AOP Sigma=(I+gL)^-1 is SMOOTH in g (no finite-g divergence): no critical point, unlike Aguilera's Phi.


# --- Adversarial re-test (8-9 July 2026): whole-side rescue quantities ---
def total_correlation(Sigma):
    """Gaussian total correlation = AOP's Integration axis: 0.5*[sum log diag(S) - logdet S]."""
    _,ld=np.linalg.slogdet(Sigma); return 0.5*(np.sum(np.log(np.diag(Sigma)))-ld)

def collective_var(Sigma):
    """Variance of the normalized all-ones (aggregate/conserved) mode."""
    n=Sigma.shape[0]; v=np.ones(n)/np.sqrt(n); return float(v@Sigma@v)

def top_mode_dominance(Sigma):
    """Fraction of total variance in the leading eigenmode (spectral concentration)."""
    w=np.sort(np.linalg.eigvalsh(Sigma))[::-1]; return float(w[0]/w.sum())

def L_k_modules(k, per, w_in=1.0, w_out=0.0):
    """k fully-connected modules of `per` nodes; within-module w_in, between w_out."""
    n=k*per; W=np.zeros((n,n))
    for a in range(k):
        nd=range(a*per,(a+1)*per)
        for i in nd:
            for j in nd:
                if i<j: W[i,j]=W[j,i]=w_in
    for a in range(k):
        for b in range(a+1,k):
            for i in range(a*per,(a+1)*per):
                for j in range(b*per,(b+1)*per):
                    W[i,j]=W[j,i]=w_out
    return np.diag(W.sum(1))-W

# RE-TEST RESULT (see verdict, Adversarial re-test section):
#  Under the inter-module weld (per=3,g=3), as w_out: 0 -> 0.4:
#    collective_var  flat 1.0000            (conserved; not the signal)  -> rescue #1 dead
#    total_correlation 1.86->1.55->1.94     (co-moves with VIF, dips ~0.1)-> rescue #2 dead
#    top_mode_dominance 0.42->0.71 WITH Phi  (tempting) -> but:
#  DECISIVE DISCRIMINATOR (k=3 independent modules, w_out=0, sweep w_in):
#    top_mode_dominance 0.267->0.320 while Phi == 0 exactly  -> rescue #3 dead
#  => No AOP whole-side quantity is the one-vs-many signal. Phi (MIP-irreducibility) is new structure,
#     distinct from BOTH the resolvability axis AND the Integration axis (TC). NULL holds, sharpened.
