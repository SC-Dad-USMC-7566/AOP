import os
import sys, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aop_ecmu_screen import (rate_ring, general_rate, stationary, transition_matrix,
                             entropy_production, memory_irreversibility, ring_pendant)

dt = 0.5

def obs_epr_via_reversal(R, emit, dt, L):
    """The script's 'memory_irreversibility' at word length L."""
    p = stationary(R)
    return memory_irreversibility(R, p, dt, L, emit)

print("="*70)
print("KILL TEST 1: extensivity in word length L (Xi is bounded; EPR is extensive)")
print("="*70)
# GO model: driven ring+pendant, asymmetric read-out
a, wp = 2.0, 0.7
R = ring_pendant(a, wp)
emit_asym = [0,0,1,2]          # reflection-symmetry-breaking lump
print(f"driven ring+pendant a={a} wp={wp}, asymmetric emit={emit_asym}")
print(f"{'L':>3} {'KL(word||rev)':>16} {'KL/(L-1)':>12}")
prev=None
for L in range(2,9):
    kl = obs_epr_via_reversal(R, emit_asym, dt, L)
    per = kl/(L-1)
    print(f"{L:>3} {kl:>16.6e} {per:>12.6e}")
print("-> if KL grows ~linearly in L and KL/(L-1) -> constant, it is an EPR rate x steps,")
print("   NOT causal irreversibility Xi (which is bounded by Cmu, finite).")

print()
print("="*70)
print("KILL TEST 2: trivial-structure control (pure driven ring, FULLY observed)")
print("="*70)
# 3-ring, no pendant, emit=identity: nothing to 'remember', pure drive.
for a in [1.0, 1.5, 2.0, 3.0]:
    R3 = rate_ring(3, 1.0, a)
    p3 = stationary(R3)
    sig = entropy_production(R3, p3)
    emit_id = [0,1,2]
    kl = memory_irreversibility(R3, p3, dt, 4, emit_id)
    print(f"a={a:>4}  sigma_dot={sig:>10.5f}   KL(word||rev), L=4 = {kl:>12.6e}")
print("-> structureless, fully-observed ring: if KL still tracks sigma_dot,")
print("   the quantity is a Drive object, independent of any memory structure.")

print()
print("="*70)
print("KILL TEST 3: does the quantity equal coarse-grained entropy production?")
print("="*70)
# Compare KL-rate to the entropy production of the observed process.
# For the FULLY observed ring, coarse-grained EPR == full EPR: KL/(L-1)/dt should approach sigma_dot.
a=2.0
R3=rate_ring(3,1.0,a); p3=stationary(R3); sig=entropy_production(R3,p3)
print(f"fully-observed 3-ring a={a}: full sigma_dot={sig:.6f}")
print(f"{'L':>3} {'KL/(L-1)/dt':>16}")
for L in range(2,10):
    kl=memory_irreversibility(R3,p3,dt,L,[0,1,2])
    print(f"{L:>3} {kl/(L-1)/dt:>16.6f}")
print(f"-> if KL/(L-1)/dt -> sigma_dot={sig:.6f}, the 'memory-irreversibility' IS")
print("   the entropy production rate (Roldan-Parrondo), i.e. a Drive quantity.")
