"""
aop_ecmu_screen.py — Gate-0 screen for the E-vs-Cmu dormancy joint (Memory x Drive).

Separate, self-contained module (does NOT touch aop_resolvability_engine.py or the trajectory FIM
modules). Tests whether a computational-mechanics memory object carries the thermodynamic drive
current through the SAME operator that sets entropy production, or is a function of the reversible
skeleton only (the pre-registered NULL).

Model: driven Markov ring, generator split into a reversible skeleton (symmetric base rates, sets the
stationary structure -> E, Cmu) and a cycle drive `a` (affinity, sets the current and sigma-dot).
Memory read out from a hidden/lumped observation (state -> symbol emit map), so the observed process
is non-Markov and its epsilon-machine is nontrivial.

Memory-irreversibility read-out (observable proxy for causal irreversibility Xi = Cmu+ - Cmu-,
verified against Crutchfield-Ellison-Mahoney "Time's Barbed Arrow" PRL 103 094101 (2009), where
Xi = H[S+|S-] - H[S-|S+] and E is scan-symmetric so cannot see it): a stationary process is
time-reversible iff P(x0..xL) = P(xL..x0); the KL divergence between the observed word distribution
and its reversal measures the observable irreversibility.

Key findings (see verdict):
  * necessity holds EXACTLY: observed memory-irreversibility = 0 (machine zero) at detailed balance
    (current=0) for every skeleton;
  * near equilibrium it scales as current^2 (R^2=0.995), the same current order as sigma-dot -> the
    memory object carries the drive through the same operator that sets sigma-dot;
  * a symmetric (reflection-invariant) read-out is current-blind at all drives -> the effect needs an
    asymmetric read-out, which the screen flags as the load-bearing scope condition for the full gate.
"""
import numpy as np
from scipy.linalg import expm, null_space
from itertools import product

def rate_ring(n,w,a):
    R=np.zeros((n,n))
    for i in range(n):
        j=(i+1)%n
        R[j,i]=w*np.sqrt(a); R[i,j]=w/np.sqrt(a)
    for i in range(n): R[i,i]=-R[:,i].sum()
    return R

def general_rate(edges,n):
    R=np.zeros((n,n))
    for (i,j),r in edges.items(): R[i,j]=r
    for j in range(n): R[j,j]=-sum(R[i,j] for i in range(n) if i!=j)
    return R

def stationary(R):
    ns=null_space(R); p=ns[:,0]; return p/p.sum()

def transition_matrix(R,dt): return expm(R*dt)

def entropy_production(R,p):
    n=R.shape[0]; s=0.0
    for i in range(n):
        for j in range(n):
            if i!=j and R[j,i]>0 and R[i,j]>0:
                s+=R[j,i]*p[i]*np.log(R[j,i]*p[i]/(R[i,j]*p[j]))
    return s

def word_dist(T,p,L,emit):
    n=T.shape[0]; wd={}
    for states in product(range(n),repeat=L):
        pr=p[states[0]]
        for k in range(L-1): pr*=T[states[k+1],states[k]]
        if pr<=0: continue
        w=tuple(emit[s] for s in states); wd[w]=wd.get(w,0)+pr
    return wd

def memory_irreversibility(R,p,dt,L,emit):
    """KL(P(word) || P(reversed word)) for the observed (lumped) process. 0 iff time-reversible."""
    T=transition_matrix(R,dt); wf=word_dist(T,p,L,emit); kl=0.0
    for k,pf in wf.items():
        pr=wf.get(tuple(reversed(k)),0.0)
        if pf>0 and pr>0: kl+=pf*np.log2(pf/pr)
    return kl

def excess_entropy(R,p,dt,emit,Lmax=9):
    T=transition_matrix(R,dt)
    def be(L):
        wd=word_dist(T,p,L,emit); ps=np.array(list(wd.values())); ps=ps[ps>0]
        return -np.sum(ps*np.log2(ps))
    H=np.array([0.0]+[be(L) for L in range(1,Lmax+1)])
    hmu=H[-1]-H[-2]; return H[Lmax]-hmu*Lmax, hmu

def ring_pendant(a,wp):
    """3-ring driven by a + a detailed-balance pendant 2<->3 (skeleton knob wp). The GO model."""
    e={(1,0):np.sqrt(a),(0,1):1/np.sqrt(a),(2,1):np.sqrt(a),(1,2):1/np.sqrt(a),
       (0,2):np.sqrt(a),(2,0):1/np.sqrt(a),(3,2):wp,(2,3):wp}
    return general_rate(e,4)


# ---------------------------------------------------------------------------
# CORRECTED memory object (added after break_ecmu.py showed memory_irreversibility
# above is the Roldan-Parrondo entropy-production estimator, a DRIVE object, NOT a
# memory object). The real computational-mechanics memory object is the causal
# irreversibility Xi = Cmu+ - Cmu-, bounded by Cmu. Screen verdict: Xi = 0 at every
# drive on the driven ring (memory is drive-blind) -> NULL. Estimator validated on
# causally-irreversible positive controls (Xi up to 0.90).
# ---------------------------------------------------------------------------
def _seq_dist(T,p,emit,L):
    n=T.shape[0]; wd={}
    for st in product(range(n),repeat=L):
        pr=p[st[0]]
        for k in range(L-1): pr*=T[st[k+1],st[k]]
        if pr>0:
            w=tuple(emit[s] for s in st); wd[w]=wd.get(w,0)+pr
    return wd

def stat_complexity(T,p,emit,D,Lf):
    """Finite-order statistical complexity: cluster length-D pasts by their next-Lf-symbol
    future morph; Cmu = H[P(causal state)] in bits."""
    wd=_seq_dist(T,p,emit,D+Lf); past_fut={}; past_p={}
    for w,pr in wd.items():
        pa,fu=w[:D],w[D:]
        past_fut.setdefault(pa,{}); past_fut[pa][fu]=past_fut[pa].get(fu,0)+pr
        past_p[pa]=past_p.get(pa,0)+pr
    morphs={pa:tuple(sorted((fu,round(v/sum(fd.values()),6)) for fu,v in fd.items()))
            for pa,fd in past_fut.items()}
    clusters={}
    for pa,m in morphs.items(): clusters[m]=clusters.get(m,0.0)+past_p[pa]
    ps=np.array(list(clusters.values())); ps=ps[ps>0]; ps/=ps.sum()
    return -np.sum(ps*np.log2(ps)), len(clusters)

def causal_irreversibility(R,emit,dt,D,Lf):
    """Xi = Cmu+ - Cmu- for the observed (lumped) process. THE memory object the screen
    should have used. Returns (Cmu_plus, Cmu_minus, Xi)."""
    p=stationary(R); T=transition_matrix(R,dt)
    Cp,_=stat_complexity(T,p,emit,D,Lf)
    n=R.shape[0]; Rr=np.zeros_like(R)
    for i in range(n):
        for j in range(n):
            if i!=j: Rr[i,j]=R[j,i]*p[j]/p[i]
    for j in range(n): Rr[j,j]=-Rr[:,j].sum()
    Cm,_=stat_complexity(transition_matrix(Rr,dt),p,emit,D,Lf)
    return Cp,Cm,Cp-Cm
