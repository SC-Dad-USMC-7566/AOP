"""
Figure MW — The semantic mask, computed.

A worked instance of the two-layer object's SEMANTIC layer: the scramble-and-
re-run mask of Kolchinsky & Wolpert (Interface Focus 8, 20180041, 2018),
applied to the internal couplings of the driven Markov ring of Figure DM.

The mask procedure (Section 3):
  for each coupling (edge):
      scramble it in isolation  -> replace the edge's directed drive with its
                                    detailed-balanced (uninformative) version
      re-run the dynamics       -> recompute the nonequilibrium steady state
      read the viability drop   -> fractional loss of a present-tense viability

The per-edge fractional viability drop IS the edge's semantic weight. An edge
whose scrambling costs nothing was decorative; an edge whose scrambling drops
viability was load-bearing.

Everything here is present-tense (Section 9): each viability functional is a
structural property of the current steady state, checkable now, requiring no
foresight.

System: a driven 3-state ring (states 0,1,2), the Figure DM family, plus one
inert spectator coupling (state 0 <-> spectator state 3) held at detailed
balance. The spectator is a real coupling that carries no directed current;
the mask should return ~0 weight for it (present but semantically inert),
and graded positive weights for the three ring edges.

Self-contained. Deposits: figure_MW_worked_mask.png and printed tables.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import gridspec

np.set_printoptions(precision=4, suppress=True)

# ----------------------------------------------------------------------
# Model: continuous-time Markov chain on 4 states.
#   Ring edges (directed drive): 0->1, 1->2, 2->0  (and reverses)
#   Spectator edge (detailed balance): 0<->3
# Edge k on the ring has forward rate f[k], backward rate b[k].
# Heterogeneous affinities ln(f/b) make the three ring edges bear different load.
# ----------------------------------------------------------------------

N = 4                       # 3 ring states + 1 spectator
RING = [(0, 1), (1, 2), (2, 0)]      # directed forward transitions
SPEC = (0, 3)               # spectator coupling, symmetric

# baseline rates
f = np.array([2.0, 3.0, 5.0])        # forward rates on ring edges
b = np.array([1.0, 1.0, 1.0])        # backward rates on ring edges
c = 1.0                              # spectator symmetric rate (0<->3)


def build_generator(f, b, c):
    """Rate matrix Q (rows sum to zero); Q[i,j] = rate i->j for i!=j."""
    Q = np.zeros((N, N))
    for k, (i, j) in enumerate(RING):
        Q[i, j] += f[k]      # forward i->j
        Q[j, i] += b[k]      # backward j->i
    i, j = SPEC
    Q[i, j] += c             # 0->3
    Q[j, i] += c             # 3->0  (symmetric => detailed balance, no current)
    for i in range(N):
        Q[i, i] = -Q[i].sum()
    return Q


def steady_state(Q):
    """Stationary distribution: solve pi Q = 0, sum pi = 1."""
    A = np.vstack([Q.T, np.ones(N)])
    rhs = np.zeros(N + 1)
    rhs[-1] = 1.0
    pi, *_ = np.linalg.lstsq(A, rhs, rcond=None)
    pi = np.clip(pi, 1e-15, None)
    return pi / pi.sum()


def edge_fluxes(Q, pi):
    """Net probability flux on each undirected edge, and its affinity term."""
    fluxes = {}
    terms = {}
    pairs = [(i, j) for i in range(N) for j in range(i + 1, N)
             if Q[i, j] > 0 or Q[j, i] > 0]
    for (i, j) in pairs:
        Jij = Q[i, j] * pi[i] - Q[j, i] * pi[j]        # net i->j flux
        fluxes[(i, j)] = Jij
        if Q[i, j] * pi[i] > 0 and Q[j, i] * pi[j] > 0:
            terms[(i, j)] = Jij * np.log((Q[i, j] * pi[i]) / (Q[j, i] * pi[j]))
        else:
            terms[(i, j)] = 0.0
    return fluxes, terms


def entropy_production(Q, pi):
    _, terms = edge_fluxes(Q, pi)
    return sum(terms.values())


def ring_current(Q, pi):
    """Circulating current = mean |net flux| over the three ring edges."""
    vals = []
    for (i, j) in RING:
        a, bb = (i, j) if i < j else (j, i)
        Jij = Q[a, bb] * pi[a] - Q[bb, a] * pi[bb]
        vals.append(abs(Jij))
    return float(np.mean(vals))


def spectral_gap(Q):
    """|Re(second-largest eigenvalue)| = relaxation rate to steady state.
    A present-tense robustness: how fast the system re-holds its shape."""
    ev = np.linalg.eigvals(Q.T)
    re = np.sort(ev.real)[::-1]      # largest is 0 (stationary)
    return abs(re[1])


# ----------------------------------------------------------------------
# Present-tense viability functionals (all structural facts of the now)
# ----------------------------------------------------------------------
def V_current(f, b, c):
    Q = build_generator(f, b, c); pi = steady_state(Q)
    return ring_current(Q, pi)

def V_sigma(f, b, c):
    Q = build_generator(f, b, c); pi = steady_state(Q)
    return entropy_production(Q, pi)

def V_gap(f, b, c):
    Q = build_generator(f, b, c)
    return spectral_gap(Q)

VIABILITIES = {
    "throughput  |J|": V_current,
    "dissipation  σ": V_sigma,
    "robustness  gap": V_gap,
}

EDGES = ["e01 (ring)", "e12 (ring)", "e20 (ring)", "e0S (spectator)"]


def scramble(f, b, c, edge_idx):
    """Replace one edge's directed drive with its detailed-balanced version.
    Ring edge k: set f[k]=b[k]=mean (removes ln(f/b), keeps escape rate).
    Spectator: already symmetric -> scrambling is a no-op (weight ~ 0)."""
    f2, b2, c2 = f.copy(), b.copy(), c
    if edge_idx < 3:
        m = 0.5 * (f2[edge_idx] + b2[edge_idx])
        f2[edge_idx] = m
        b2[edge_idx] = m
    else:
        pass   # spectator has no directed content to scramble
    return f2, b2, c2


def semantic_weights(f, b, c):
    """Per-edge fractional viability drop under each viability functional."""
    W = {}
    for vname, V in VIABILITIES.items():
        base = V(f, b, c)
        row = []
        for e in range(4):
            fs, bs, cs = scramble(f, b, c, e)
            drop = (base - V(fs, bs, cs)) / base if base > 1e-12 else 0.0
            row.append(max(0.0, drop))
        W[vname] = np.array(row)
    return W


# ----------------------------------------------------------------------
# Compute
# ----------------------------------------------------------------------
Q0 = build_generator(f, b, c)
pi0 = steady_state(Q0)
sigma0 = entropy_production(Q0, pi0)
J0 = ring_current(Q0, pi0)

print("=== Baseline (driven ring + inert spectator) ===")
print("steady state pi:", pi0)
print(f"entropy production sigma = {sigma0:.4f} nats/time   (must be > 0)")
print(f"ring current |J|         = {J0:.4f}")
fluxes, _ = edge_fluxes(Q0, pi0)
print("net edge fluxes:", {f"{k}": round(v, 4) for k, v in fluxes.items()})
print("  -> ring edges carry equal current; spectator (0,3) ~ 0\n")

W = semantic_weights(f, b, c)
print("=== Semantic weights (fractional viability drop when edge scrambled) ===")
header = "edge".ljust(18) + "".join(v.ljust(18) for v in VIABILITIES)
print(header)
for e in range(4):
    line = EDGES[e].ljust(18)
    for v in VIABILITIES:
        line += f"{W[v][e]:.3f}".ljust(18)
    print(line)

# range across viability functionals (the "characteristic measurable")
stack = np.vstack([W[v] for v in VIABILITIES])
wmin, wmax, wmean = stack.min(0), stack.max(0), stack.mean(0)
print("\n=== Range each weight sweeps across viability choices ===")
for e in range(4):
    print(f"{EDGES[e].ljust(18)} mean={wmean[e]:.3f}  range=[{wmin[e]:.3f}, {wmax[e]:.3f}]")

# rank stability check (Comolatti-Hoel pattern: rank survives, magnitude doesn't)
print("\nrank of ring edges under each functional (1=most load-bearing):")
for v in VIABILITIES:
    order = np.argsort(-W[v][:3])
    rank = np.empty(3, int); rank[order] = np.arange(1, 4)
    print(f"  {v.ljust(18)} {dict(zip([e[:3] for e in EDGES[:3]], rank.tolist()))}")

# ----------------------------------------------------------------------
# Negative control: at detailed balance (no drive) the mask must be empty
# ----------------------------------------------------------------------
f_eq = np.array([1.0, 1.0, 1.0]); b_eq = np.array([1.0, 1.0, 1.0])
Qeq = build_generator(f_eq, b_eq, c); pieq = steady_state(Qeq)
print("\n=== Negative control: detailed-balance ring (no drive) ===")
print(f"sigma = {entropy_production(Qeq, pieq):.2e}, |J| = {ring_current(Qeq, pieq):.2e}")
Weq = semantic_weights(f_eq, b_eq, c)
print("throughput weights:", Weq['throughput  |J|'],
      " -> no drive => no load-bearing couplings (semantics spent)")

# ----------------------------------------------------------------------
# Figure
# ----------------------------------------------------------------------
fig = plt.figure(figsize=(11, 4.2))
gs = gridspec.GridSpec(1, 2, width_ratios=[1.25, 1.0], wspace=0.32)

colors = {"throughput  |J|": "#2c7fb8",
          "dissipation  σ": "#d95f0e",
          "robustness  gap": "#31a354"}

# Panel A: per-edge weights under each viability functional (grouped bars)
axA = fig.add_subplot(gs[0])
x = np.arange(4); w = 0.25
for k, v in enumerate(VIABILITIES):
    axA.bar(x + (k - 1) * w, W[v], w, label=v, color=colors[v], edgecolor="k", lw=0.4)
axA.set_xticks(x)
axA.set_xticklabels(EDGES, rotation=12, fontsize=8.5)
axA.set_ylabel("semantic weight\n(fractional viability drop)", fontsize=9)
axA.set_title("A  The mask returns per-edge weights", fontsize=10, loc="left")
axA.legend(fontsize=8, frameon=False, title="present-tense viability", title_fontsize=8)
axA.axhline(0, color="k", lw=0.6)
axA.margins(y=0.15)
axA.text(3, max(0.02, W['throughput  |J|'][3] + 0.03),
         "inert:\npresent but\nload-free", ha="center", va="bottom", fontsize=7.5, color="#555")

# Panel B: each edge as a horizontal range (the characteristic measurable)
axB = fig.add_subplot(gs[1])
y = np.arange(4)[::-1]
for e in range(4):
    axB.plot([wmin[e], wmax[e]], [y[e], y[e]], "-", color="#888", lw=2, zorder=1)
    for k, v in enumerate(VIABILITIES):
        axB.scatter(W[v][e], y[e], color=colors[v], s=28, zorder=3, edgecolor="k", lw=0.3)
axB.set_yticks(y)
axB.set_yticklabels(EDGES, fontsize=8.5)
axB.set_xlabel("semantic weight", fontsize=9)
axB.set_title("B  Each weight is a range, not a point", fontsize=10, loc="left")
axB.set_xlim(-0.03, max(wmax) * 1.15 + 0.03)
axB.axvline(0, color="k", lw=0.6)
axB.text(0.98, 0.02,
         "width = observer-relativity\nof semantic weight\n(the framework's measurable)",
         transform=axB.transAxes, ha="right", va="bottom", fontsize=7.5, color="#555")

fig.suptitle("Figure MW.  The semantic mask, computed on the Figure DM driven ring",
             fontsize=11, x=0.02, ha="left", y=1.02, weight="bold")
fig.savefig("figure_MW_worked_mask.png", dpi=170, bbox_inches="tight")
print("\nsaved figure_MW_worked_mask.png")
