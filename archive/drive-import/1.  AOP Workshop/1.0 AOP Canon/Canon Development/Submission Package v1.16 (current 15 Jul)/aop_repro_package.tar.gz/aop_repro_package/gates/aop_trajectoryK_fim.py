"""
aop_trajectoryK_fim.py — Gate 0b-trajectory-K read-out (coupling resolvability under nuisance drive).

Corrects the *object* the snapshot and trajectory-B nulls measured. AOP resolvability is read on the
coupling / precision partition K = Sigma^-1 = (I+gL) (ratified global convention K1), with the drive Q
co-estimated as a nuisance. The primary object is the nuisance-robust (effective) Fisher information
for the entries of K — the Schur complement of the joint drift-entry FIM onto the K-block:

    F_K|Q = F_KK - F_KQ F_QQ^-1 F_QK.

Effective-Fisher / Schur-complement construction verified against the downloaded PDF bodies of two
primary sources (K3): the effective Fisher information for parameters of interest after profiling
nuisance parameters is F_eff = F_θθ - F_θφ F_φφ^-1 F_φθ. Singh & Fujiwara, quantum estimation w/
nuisance parameters, arXiv:1911.02790, eq. (13): J_θ(I|N) = J_{θ;I,I} - J_{θ;I,N}(J_{θ;N,N})^-1
J_{θ;N,I}, the "partial Fisher information matrix for the parameters of interest," which the text
states "follows from well-known Schur's complements" (both verified verbatim in the body). Nissanke
et al., arXiv:1508.03634, eq. (C21): the marginalized-Fisher upper-left block A~^-1 = A - B D^-1 C is
named the Schur complement in the body. The joint drift-entry
FIM is F_B = T*(Sigma (x) (2D)^-1) over vec(B), reparameterized to theta=(sym K params, antisym Q
params) by the exact Jacobian dB/dK_a=(D+Q)S_a, dB/dQ_b=A_b K.

Coexists with the snapshot lens (Q=0) and the trajectory-B lens (fused generator); this is the Q!=0
coupling-primary object. Deciding computation is the CONSTRAINED FLOOR min_Q cond(F_K|Q) s.t. sigdot=c
(K5: sampled Q is only an inner bound).
"""
import numpy as np
from scipy.optimize import minimize

def sym_basis(n):
    B=[]
    for i in range(n):
        for j in range(i,n):
            S=np.zeros((n,n)); S[i,j]=1; S[j,i]=1; B.append(S)
    return B

def anti_basis(n):
    B=[]
    for i in range(n):
        for j in range(i+1,n):
            A=np.zeros((n,n)); A[i,j]=1; A[j,i]=-1; B.append(A)
    return B

def sigdot(Sigma,D,Q):
    K=np.linalg.inv(Sigma)
    return float(np.trace(np.linalg.inv(D)@Q@K@Q.T))

def _F_theta(Sigma,D,Q):
    n=Sigma.shape[0]; K=np.linalg.inv(Sigma)
    F_B=np.kron(Sigma,np.linalg.inv(2*D))          # over vec(B) col-stack, T=1
    DpQ=D+Q; Sb=sym_basis(n); Ab=anti_basis(n)
    cols=[ (DpQ@S).flatten("F") for S in Sb ] + [ (A@K).flatten("F") for A in Ab ]
    J=np.array(cols).T
    return J.T@F_B@J, len(Sb), len(Ab)

def _cond(M):
    w=np.linalg.eigvalsh((M+M.T)/2); w=w[w>1e-12*w.max()]; return w.max()/w.min()

def cond_FK_given_Q(Sigma,D,Q):
    """Return (co-estimated cond via Schur, drive-known cond of K-block)."""
    Ft,nk,nq=_F_theta(Sigma,D,Q)
    FKK=Ft[:nk,:nk]; FKQ=Ft[:nk,nk:]; FQQ=Ft[nk:,nk:]
    S=FKK-FKQ@np.linalg.solve(FQQ,FKQ.T) if nq>0 else FKK
    return _cond(S), _cond(FKK)

def _anti_from_params(p,n):
    A=np.zeros((n,n)); k=0
    for i in range(n):
        for j in range(i+1,n):
            A[i,j]=p[k]; A[j,i]=-p[k]; k+=1
    return A

def floor_at_cost(Sigma,D,c,n_restart=10,seed=1):
    """min over antisymmetric Q of cond(F_K|Q) subject to sigdot(Q)=c (the deciding computation)."""
    n=Sigma.shape[0]; npar=n*(n-1)//2; rng=np.random.default_rng(seed); best=np.inf
    if c<=0: return cond_FK_given_Q(Sigma,D,np.zeros((n,n)))[0]
    for _ in range(n_restart):
        u0=rng.standard_normal(npar)
        def obj(u):
            Q=_anti_from_params(u,n); sd=sigdot(Sigma,D,Q)
            if sd<=1e-12: return 1e9
            Q=Q*np.sqrt(c/sd); return np.log(cond_FK_given_Q(Sigma,D,Q)[0])
        r=minimize(obj,u0,method="Nelder-Mead",options={"maxiter":2000,"xatol":1e-4,"fatol":1e-5})
        best=min(best,np.exp(r.fun))
    return best
