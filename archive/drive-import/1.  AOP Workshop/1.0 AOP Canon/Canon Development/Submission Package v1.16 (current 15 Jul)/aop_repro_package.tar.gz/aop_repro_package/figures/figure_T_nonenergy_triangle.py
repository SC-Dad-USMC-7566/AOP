# skill:figure-style kernel.py (auto-injected on skill load)
META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


def panel_letter(ax, letter, dx=-0.18, dy=1.02, case="lower", fontsize=None):
    import matplotlib.pyplot as plt
    if fontsize is None:
        fontsize = plt.rcParams.get("font.size", 8) + 1
    s = letter.lower() if case == "lower" else letter.upper()
    ax.text(dx, dy, s, transform=ax.transAxes,
            fontweight="bold", fontsize=fontsize, va="bottom", ha="left")


import numpy as np
from scipy.linalg import solve_discrete_lyapunov

def stationary_cov(A, Sig):
    return solve_discrete_lyapunov(A, Sig)

def logdet(M):
    s, ld = np.linalg.slogdet(M); return ld

def integration(C):
    return 0.5*(np.log(np.diag(C)).sum() - logdet(C))

def boundary(C, inside):
    n=C.shape[0]; outside=[i for i in range(n) if i not in inside]
    Cii=C[np.ix_(inside,inside)]; Coo=C[np.ix_(outside,outside)]
    return 0.5*(logdet(Cii)+logdet(Coo)-logdet(C))

def memory(A, C):
    n=C.shape[0]
    top=np.hstack([C, C@A.T]); bot=np.hstack([A@C, C])
    J=np.vstack([top,bot])
    return 0.5*(logdet(C)+logdet(C)-logdet(J))

def equicorr(n,rho):
    R=np.full((n,n),rho); np.fill_diagonal(R,1.0); return R

n=4; inside=[0,1]
I4=np.eye(4)

rng=np.random.default_rng(0)
def rand_system():
    M_=rng.normal(0,1,(4,4))
    A=M_/ (np.abs(np.linalg.eigvals(M_)).max()) * rng.uniform(0.0,0.9)
    L=rng.normal(0,1,(4,4)); Sig=L@L.T/4 + np.eye(4)*0.1
    return A,Sig

vals=[]
for _ in range(4000):
    A,S=rand_system()
    try:
        C=stationary_cov(A,S)
        vals.append((boundary(C,inside), memory(A,C), integration(C)))
    except Exception:
        pass
V=np.array(vals)
Bv,Mv,Iv=V[:,0],V[:,1],V[:,2]
corr=np.corrcoef(V.T)

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
apply_figure_style()

fig=plt.figure(figsize=(7.6,3.4))
ax=fig.add_subplot(1,2,1,projection='3d')
sc=ax.scatter(Bv,Iv,Mv,c=Mv,cmap='viridis',s=3,alpha=0.35)
ax.set_xlabel('Boundary',fontsize=7,labelpad=-4); ax.set_ylabel('Integration',fontsize=7,labelpad=-4)
ax.set_zlabel('Memory',fontsize=7,labelpad=-4)
ax.tick_params(labelsize=5,pad=-2)
ax.set_title('4000 random VAR(1) systems',fontsize=8)
ax.view_init(elev=18,azim=-60)

ax2=fig.add_subplot(1,2,2)
labels=["memory\nonly","blob\n(no mem)","sealed\nmodules","all\nthree","cross-cut\npair"]
Bvals=[0.0,0.567,0.0,0.350,0.830]; Mvals=[2.564,0.0,0.0,0.893,0.0]; Ivals=[0.0,1.240,2.049,0.710,0.830]
x=np.arange(5); w=0.26
ax2.bar(x-w,Bvals,w,label='Boundary',color='#c1440e')
ax2.bar(x,  Mvals,w,label='Memory',color='#1f6f8b')
ax2.bar(x+w,Ivals,w,label='Integration',color='#7b5aa6')
ax2.set_xticks(x); ax2.set_xticklabels(labels,fontsize=5.6)
ax2.set_ylabel('nats')
ax2.set_title('Every corner is reachable by construction',fontsize=8,loc='left')
ax2.legend(frameon=False,fontsize=6,ncol=3,loc='upper center',bbox_to_anchor=(0.5,1.0))
ax2.margins(y=0.15)
panel_letter(ax2,'b')
fig.text(0.055,0.9,'a',fontsize=9,fontweight='bold')
fig.tight_layout()
fig.savefig("aop_nonenergy_triangle.png",dpi=300,bbox_inches='tight')
print("saved | corr(B,M)=%.3f corr(M,I)=%.3f corr(B,I)=%.3f"%(corr[0,1],corr[1,2],corr[0,2]))